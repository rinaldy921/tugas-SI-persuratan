<?php

/**
 * This is the model class for table "iuphhk_tenaga_kerja".
 *
 * The followings are the available columns in table 'iuphhk_tenaga_kerja':
 * @property integer $id
 * @property integer $id_perusahaan
 * @property integer $id_jenis_tenaga_kerja
 * @property integer $id_kualifikasi
 * @property integer $id_pendidikan
 * @property string $nama
 * @property string $no_sertifikat
 * @property string $tgl_awal_sertifikat
 * @property string $tgl_akhir_sertifikat
 * @property string $is_aktif
 *
 * The followings are the available model relations:
 * @property Perusahaan $idPerusahaan
 * @property MasterKualifikasi $idKualifikasi
 * @property MasterPendidikan $idPendidikan
 */
class IuphhkTenagaKerja extends CActiveRecord
{
	public $Berlaku;
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'iuphhk_tenaga_kerja';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('id_perusahaan,id_jenis_tenaga_kerja, id_pendidikan, nama, no_reg, tgl_lahir, alamat, tgl_awal_sertifikat, tgl_akhir_sertifikat, no_sertifikat', 'required'),
			array('id, id_perusahaan, id_jenis_tenaga_kerja, id_kualifikasi, id_pendidikan', 'numerical', 'integerOnly'=>true),
			array('nama, no_sertifikat, no_reg', 'length', 'max'=>50),
			array('is_aktif', 'length', 'max'=>1),
			array('tgl_awal_sertifikat, tgl_akhir_sertifikat, tgl_lahir', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, id_perusahaan, id_jenis_tenaga_kerja, id_kualifikasi, id_pendidikan, nama, no_sertifikat, tgl_awal_sertifikat, tgl_akhir_sertifikat, is_aktif', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'idPerusahaan' => array(self::BELONGS_TO, 'Perusahaan', 'id_perusahaan'),
			'idKualifikasi' => array(self::BELONGS_TO, 'MasterKualifikasi', 'id_kualifikasi'),
			'idPendidikan' => array(self::BELONGS_TO, 'MasterPendidikan', 'id_pendidikan'),
			'idGanis'	=> array(self::BELONGS_TO, 'MasterJenisGanis', 'id_jenis_tenaga_kerja')
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
						'id'=>Yii::t('app','ID'),
						'id_perusahaan'=>Yii::t('app','Id Perusahaan'),
						'id_jenis_tenaga_kerja'=>Yii::t('app','Jenis Tenaga Teknis'),
						'id_kualifikasi'=>Yii::t('app','Kualifikasi'),
						'id_pendidikan'=>Yii::t('app','Pendidikan'),
						'nama'=>Yii::t('app','Nama'),
						'no_sertifikat'=>Yii::t('app','No SK'),
						'tgl_awal_sertifikat'=>Yii::t('app','Tgl Awal Sertifikat'),
						'tgl_akhir_sertifikat'=>Yii::t('app','Tgl Akhir Sertifikat'),
						'is_aktif'=>"Status",//Yii::t('app','Is Aktif'),
						'no_reg' => "Nomor Registrasi",
						'tempat_lahir' => "Tempat Lahir",
						"tgl_lahir" => "Tgl Lahir",
						"alamat" => "Alamat",
						'tgl_keluar' => "Tgl Keluar"
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('id_perusahaan',$this->id_perusahaan);
		$criteria->compare('id_jenis_tenaga_kerja',$this->id_jenis_tenaga_kerja);
		$criteria->compare('id_kualifikasi',$this->id_kualifikasi);
		$criteria->compare('id_pendidikan',$this->id_pendidikan);
		$criteria->compare('nama',$this->nama,true);
		$criteria->compare('no_sertifikat',$this->no_sertifikat,true);
		$criteria->compare('tgl_awal_sertifikat',$this->tgl_awal_sertifikat,true);
		$criteria->compare('tgl_akhir_sertifikat',$this->tgl_akhir_sertifikat,true);
		$criteria->compare('is_aktif',$this->is_aktif,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return IuphhkTenagaKerja the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
