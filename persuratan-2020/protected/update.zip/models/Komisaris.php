<?php

/**
 * This is the model class for table "komisaris".
 *
 * The followings are the available columns in table 'komisaris':
 * @property integer $id_komisaris
 * @property integer $perusahaan_id
 * @property string $nama_komisaris
 * @property string $jabatan
 *
 * The followings are the available model relations:
 * @property Perusahaan $perusahaan
 */
class Komisaris extends CActiveRecord {

    /**
     * @return string the associated database table name
     */
    public function tableName() {
        return 'komisaris';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules() {
        // NOTE: you should only define rules for those attributes that
        // will receive user inputs.
        return array(
            array('perusahaan_id, nama_komisaris, jabatan', 'required'),
            array('perusahaan_id', 'numerical', 'integerOnly' => true),
            array('nama_komisaris, jabatan', 'length', 'max' => 50),
            // The following rule is used by search().
            // @todo Please remove those attributes that should not be searched.
            array('id_komisaris, perusahaan_id, nama_komisaris, jabatan, id_legalitas', 'safe', 'on' => 'search'),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations() {
        // NOTE: you may need to adjust the relation name and the related
        // class name for the relations automatically generated below.
        return array(
            'perusahaan' => array(self::BELONGS_TO, 'Perusahaan', 'perusahaan_id'),
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels() {
        return array(
            'id_komisaris' => 'Id Komisaris',
            'perusahaan_id' => 'Perusahaan',
            'nama_komisaris' => 'Nama Komisaris',
            'jabatan' => 'Jabatan',
            'id_legalitas' => 'id_legalitas'
        );
    }

    /**
     * Retrieves a list of models based on the current search/filter conditions.
     *
     * Typical usecase:
     * - Initialize the model fields with values from filter form.
     * - Execute this method to get CActiveDataProvider instance which will filter
     * models according to data in model fields.
     * - Pass data provider to CGridView, CListView or any similar widget.
     *
     * @return CActiveDataProvider the data provider that can return the models
     * based on the search/filter conditions.
     */
    public function search() {
        // @todo Please modify the following code to remove attributes that should not be searched.

        $criteria = new CDbCriteria;

        $criteria->compare('id_komisaris', $this->id_komisaris);
        $criteria->compare('perusahaan_id', $this->perusahaan_id);
        $criteria->compare('nama_komisaris', $this->nama_komisaris, true);
        $criteria->compare('jabatan', $this->jabatan, true);
        $criteria->compare('id_legalitas', $this->id_legalitas, true);

        return new CActiveDataProvider($this, array(
            'criteria' => $criteria,
        ));
    }

    /**
     * Returns the static model of the specified AR class.
     * Please note that you should have this exact method in all your CActiveRecord descendants!
     * @param string $className active record class name.
     * @return Komisaris the static model class
     */
    public static function model($className = __CLASS__) {
        return parent::model($className);
    }

}
