<?php

/**
 * This is the model class for table "master_jenis_ganis".
 *
 * The followings are the available columns in table 'master_jenis_ganis':
 * @property integer $id
 * @property string $nama_jenis
 * @property double $val1
 * @property double $val2
 * @property double $val3
 * @property double $val4
 *
 * The followings are the available model relations:
 * @property RktEvaluasiKeberhasilan[] $rktEvaluasiKeberhasilans
 * @property RktEvaluasiPantauOperasional[] $rktEvaluasiPantauOperasionals
 * @property RktGanis[] $rktGanises
 * @property RkuGanis[] $rkuGanises
 */
class MasterJenisGanis extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'master_jenis_ganis';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('nama_jenis', 'required'),
			array('val1, val2, val3, val4', 'numerical'),
			array('nama_jenis', 'length', 'max'=>255),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, nama_jenis, val1, val2, val3, val4', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'rktEvaluasiKeberhasilans' => array(self::HAS_MANY, 'RktEvaluasiKeberhasilan', 'id_ganis'),
			'rktEvaluasiPantauOperasionals' => array(self::HAS_MANY, 'RktEvaluasiPantauOperasional', 'id_ganis'),
			'rktGanises' => array(self::HAS_MANY, 'RktGanis', 'id_ganis'),
			'rkuGanises' => array(self::HAS_MANY, 'RkuGanis', 'id_ganis'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'nama_jenis' => 'Nama Jenis',
			'val1' => Yii::t('app','val1'),
			'val2' => Yii::t('app','val2'),
			'val3' => Yii::t('app','val3'),
			'val4' => Yii::t('app','val4'),
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('nama_jenis',$this->nama_jenis,true);
		$criteria->compare('val1',$this->val1);
		$criteria->compare('val2',$this->val2);
		$criteria->compare('val3',$this->val3);
		$criteria->compare('val4',$this->val4);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return MasterJenisGanis the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
