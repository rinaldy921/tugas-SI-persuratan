<div id="header">
    <table width="100%" border="0">
        <tr>
            <td width="13%"><img width="80" src="<?php echo Yii::app()->baseUrl; ?>/img/logo22.png"></td>
            <td>
                <h4>Kementerian Lingkungan Hidup dan Kehutanan</h4>
                <h5>Direktorat Usaha Hutan Produksi</h5>
            </td>
        </tr>
    </table>
</div>