<?php
/* @var $this DefaultController */

$this->breadcrumbs=array(
	'Dashboard',
);
?>
<h1>Selamat Datang</h1>
