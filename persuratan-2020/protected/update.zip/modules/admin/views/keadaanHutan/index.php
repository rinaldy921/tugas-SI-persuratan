<?php $label = Logic::getLastLoginByPerusahan($iup->id_perusahaan);?>
<?php
$this->breadcrumbs = array(
    'IUPHHK-HTI' => array('//admin/iuphhk/index'),
    $iup->idPerusahaan->nama_perusahaan
);
?>
<div id="page-wrapper" class="col-md-12">
    <div class="panel panel-success">
        <table class="detail-view table">
            <tbody>
                <tr>
                    <th>Nomor SK</th>
                    <td><?= $iup->nomor ?></td>
                    <th>Nama Perusahaan</th>
                    <td><?= $iup->idPerusahaan->nama_perusahaan ?></td>
                </tr>
                <tr>
                    <th>Tanggak Keputusan</th>
                    <td><?= $this->getDateMonth($iup->tanggal) ?></td>
                    <th>Telepon</th>
                    <td><?= $iup->idPerusahaan->telepon ?></td>
                </tr>
                <tr>
                    <th>Luas Areal</th>
                    <td><?= floatval($iup->luas) ?> Ha</td>
                    <th>Alamat</th>
                    <td><?= $iup->idPerusahaan->alamat ?></td>
                </tr>
                <tr>
                    <th></th>
                    <td></td>
                    <th>Login Terakhir</th>
                    <td class=""><?=$label?></td>
                </tr>                
            </tbody>
        </table>
    </div>
</div>
<div class="col-md-3">
    <div class="navbar-default sidebar" role="navigation">
        <div class="navbar-default sidebar-nav">
            <?php require_once dirname(__FILE__) . '/../layouts/menu_rkt.php'; ?>
        </div>
    </div>
</div>
<div id="page-wrapper" class="col-md-9">
    <h4>Keadaan Hutan</h4>
    <?php
    $this->widget('booster.widgets.TbGridView', array(
        'id' => Yii::app()->controller->id . '-grid',
        'type' => 'bordered condensed striped',
        'responsiveTable' => true,
        'dataProvider' => $model->search(),
        'enableSorting' => false,
        'template' => '{items}{pager}',
        'columns' => array(
            array(
                'name' => 'id_penutupan_lahan',
                'header' => 'Penutupan Lahan',
                'headerHtmlOptions' => array('class' => 'hidden'),
                'value' => '$data->idPenutupanLahan->jenis_penutupan'
            ),
            array(
                'name' => 'hpt',
                'type' => 'raw',
            ),
            array(
                'name' => 'hp',
                'type' => 'raw',
            ),
            array(
                'name' => 'hpk',
                'type' => 'raw',
            ),
            array(
                'name' => 'apl',
                'type' => 'raw',
            ),
        ),
    ));
    ?>
</div>
<?php
Yii::app()->clientScript->registerScript("addTh", "
$('#" . Yii::app()->controller->id . "-grid table thead').prepend('<tr><th rowspan=\'2\' style=\'text-align: center; vertical-align: middle\'>Penutupan Lahan</th><th colspan=\'4\' style=\'text-align: center; vertical-align: middle\'>Fungsi Hutan</th></tr>')
", CClientScript::POS_END);