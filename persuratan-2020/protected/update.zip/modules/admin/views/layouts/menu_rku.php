<?php

$this->widget('zii.widgets.CMenu', array(
    'encodeLabel' => FALSE,
    'htmlOptions' => array('id' => 'side-menu', 'class' => 'nav'),
    'submenuHtmlOptions' => array('class' => 'nav nav-pills nav-stacked nav-submenu'),
    'items' => array(
        array(
            'label' => 'Adendum SK',
            'url' => array('/admin/adendum/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'adendum') ? true : false
        ),
        array(
            'label' => 'Data Administrasi',
            'url' => array('/admin/administrasi/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'administrasi') ? true : false
        ),
        array(
            'label' => 'Data Umum Areal IUPHHK-HTI',
            'url' => array('/admin/dataUmum/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'dataUmum') ? true : false
        ),
        array(
            'label' => 'Data Keadaan Hutan',
            'url' => array('/admin/keadaanHutan/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'keadaanHutan') ? true : false
        ),
        array(
            'label' => 'Data Hidrologi',
            'url' => array('/admin/hidrologi/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'hidrologi') ? true : false
        ),
        array(
            'label' => 'Data Geologi',
            'url' => array('/admin/geologi/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'geologi') ? true : false
        ),
        array(
            'label' => 'Data Fasilitas',
            'url' => array('/admin/fasilitas/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'fasilitas') ? true : false
        ),
        array(
            'label' => 'Data Penduduk',
            'url' => array('/admin/penduduk/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'penduduk') ? true : false
        ),
        array(
            'label' => Yii::t('app', 'Rencana Kerja Umum (RKU)'),
            'url' => 'javascript:{}',
            'items' => array(
                array(
                    'label' => 'Legalitas',
                    'url' => array('/admin/rku/' . Yii::app()->request->getQuery('id')),
                    'active' => (Yii::app()->controller->id == 'rku') ? true : false,
                    'items' => array(
                        array(
                            'label' => 'Sistem Silvikultur',
                            'url' => array('/admin/sistemSilvikultur/' . Yii::app()->request->getQuery('id')),
                            'active' => (Yii::app()->controller->id == 'sistemSilvikultur') ? true : false
                        ),
                        array(
                            'label' => 'Prasyarat',
                            'url' => array('/admin/rkuPrasyarat/' . Yii::app()->request->getQuery('id')),
                            'active' => (Yii::app()->controller->id == 'rkuPrasyarat') ? true : false
                        ),
                        array(
                            'label' => 'Kelestarian Fungsi Produksi',
                            'url' => array('/admin/rkuProduksi/' . Yii::app()->request->getQuery('id')),
                            'active' => (Yii::app()->controller->id == 'rkuProduksi') ? true : false
                        ),
                        array(
                            'label' => 'Kelestarian Fungsi Lingkungan',
                            'url' => array('/admin/rkuLingkungan/' . Yii::app()->request->getQuery('id')),
                            'active' => (Yii::app()->controller->id == 'rkuLingkungan') ? true : false
                        ),
                        array(
                            'label' => 'Kelestarian Fungsi Sosial',
                            'url' => array('/admin/rkuSosial/' . Yii::app()->request->getQuery('id')),
                            'active' => (Yii::app()->controller->id == 'rkuSosial') ? true : false
                        )
                    )
                )
            )
        ),
        array(
            'label' => 'Rencana Kerja Tahunan (RKT)',
            'url' => array('/admin/rkt/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'rkt') ? true : false
        ),
        array(
            'label' => 'Rekapitulasi RKT',
            'url' => array('/admin/rekapPrasyarat/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'rekapPrasyarat') ? true : false
        ),		                
        array(
            'label' => 'Laporan Kinerja',
            'url' => array('/admin/laporan/' . Yii::app()->request->getQuery('id')),
            'active' => (Yii::app()->controller->id == 'laporan') ? true : false
        ),
    ),
));
