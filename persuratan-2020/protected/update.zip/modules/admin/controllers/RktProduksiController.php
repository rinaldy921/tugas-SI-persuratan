<?php

class RktProduksiController extends Controller {

    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    /**
     * @return array action filters
     */
    public function filters() {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules() {
        return array(
            array('allow', // allow all users to perform 'index' and 'view' actions
                'actions' => array('index', 'view'),
                'users' => array(Yii::app()->user->adminRole()),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }

    /**
     * Displays a particular model.
     * @param integer $id the ID of the model to be displayed
     */

    /**
     * Manages all models.
     */
    public function actionIndex($id) {
        $iup = Iuphhk::model()->findByPk($id);
        if (!isset($iup)) {
            $message = Yii::t('app', 'Data IUPHHK yang anda pilih belum tersedia.');
            Yii::app()->user->setFlash('notice', $message);
            $this->redirect(array('//admin/iuphhk/index'));
        }
        $rkt = Rkt::model()->find(array('condition' => 'status = 1 AND id_perusahaan = ' . $iup->id_perusahaan,'order'=>'tahun_mulai DESC'));
        if (isset($_POST['Rkt'])) {
            $rkt = Rkt::model()->find(array('condition' => 'status = 1 AND id_perusahaan = ' . $iup->id_perusahaan . ' AND tahun_mulai = ' . $_POST['Rkt']['tahun_mulai'],'order'=>'tahun_mulai DESC'));
            if (!isset($rkt)) {
                $message = Yii::t('app', 'Data RKT tahun ' . $_POST['Rkt']['tahun_mulai'] . ' belum tersedia.');
                Yii::app()->user->setFlash('notice', $message);
                $this->redirect(array('//admin/rkt/' . $id));
            }
        }
        if (isset($rkt)) {
            $modelBibit = new RktBibit;
            $modelBibit->unsetAttributes();
            if (isset($_GET['RktBibit']))
                $modelBibit->attributes = $_GET['RktBibit'];
            $modelBibit->id_rkt = $rkt->id;

            $modelSiapLahan = new RktSiapLahan;
            $modelSiapLahan->unsetAttributes();
            if (isset($_GET['RktSiapLahan']))
                $modelSiapLahan->attributes = $_GET['RktSiapLahan'];
            $modelSiapLahan->id_rkt = $rkt->id;

            $modelTanam = new RktTanam;
            $modelTanam->unsetAttributes();
            if (isset($_GET['RktTanam']))
                $modelTanam->attributes = $_GET['RktTanam'];
            $modelTanam->id_rkt = $rkt->id;

            $modelSulam = new RktSulam;
            $modelSulam->unsetAttributes();
            if (isset($_GET['RktSulam']))
                $modelSulam->attributes = $_GET['RktSulam'];
            $modelSulam->id_rkt = $rkt->id;

            $modelJarang = new RktJarang;
            $modelJarang->unsetAttributes();
            if (isset($_GET['RktJarang']))
                $modelJarang->attributes = $_GET['RktJarang'];
            $modelJarang->id_rkt = $rkt->id;

            $modelDangir = new RktDangir;
            $modelDangir->unsetAttributes();
            if (isset($_GET['RktDangir']))
                $modelDangir->attributes = $_GET['RktDangir'];
            $modelDangir->id_rkt = $rkt->id;

            $modelPasar = new RktPasar;
            $modelPasar->unsetAttributes();
            if (isset($_GET['RktPasar']))
                $modelPasar->attributes = $_GET['RktPasar'];
            $modelPasar->id_rkt = $rkt->id;

            $modelPanenAreal = new RktPanenAreal;
            $modelPanenAreal->unsetAttributes();
            if (isset($_GET['RktPanenAreal']))
                $modelPanenAreal->attributes = $_GET['RktPanenAreal'];
            $modelPanenAreal->id_rkt = $rkt->id;

            $modelPanenTanaman = new RktPanenVolumeTanaman;
            $modelPanenTanaman->unsetAttributes();
            if (isset($_GET['RktPanenVolumeTanaman']))
                $modelPanenTanaman->attributes = $_GET['RktPanenVolumeTanaman'];
            $modelPanenTanaman->id_rkt = $rkt->id;

            $modelPanenSiapLahan = new RktPanenVolumeSiapLahan;
            $modelPanenSiapLahan->unsetAttributes();
            if (isset($_GET['RktPanenVolumeSiapLahan']))
                $modelPanenSiapLahan->attributes = $_GET['RktPanenVolumeSiapLahan'];
            $modelPanenSiapLahan->id_rkt = $rkt->id;
        } else {
            $message = Yii::t('app', 'Data RKT Belum ada');
            Yii::app()->user->setFlash('error', $message);
            $this->redirect(array('//admin/rkt/' . $id));
        }

        $this->render('index', array(
            'iup' => $iup,
            'model' => $rkt,
            'modelBibit' => $modelBibit,
            'modelSiapLahan' => $modelSiapLahan,
            'modelTanam' => $modelTanam,
            'modelSulam' => $modelSulam,
            'modelJarang' => $modelJarang,
            'modelDangir' => $modelDangir,
            'modelPanenAreal' => $modelPanenAreal,
            'modelPanenTanaman' => $modelPanenTanaman,
            'modelPanenSiapLahan' => $modelPanenSiapLahan,
            'modelPasar' => $modelPasar
        ));
    }

}
