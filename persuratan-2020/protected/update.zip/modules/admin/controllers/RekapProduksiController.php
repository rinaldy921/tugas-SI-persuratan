<?php

class RekapProduksiController extends Controller {

    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    
    public function actionIndex($id) {
      
        //die($id);
        $iup = Iuphhk::model()->findByPk($id);
        //debug($iup->idPerusahaan);
        if (!isset($iup)) {
            $message = Yii::t('app', 'Data IUPHHK yang anda pilih belum tersedia.');
            Yii::app()->user->setFlash('notice', $message);
            $this->redirect(array('//admin/iuphhk/index'));
        }        
        $periodeModel = new FormPeriodeRekapPrasyarat();
        //debug($iup->id_perusahaan);
        $periodeModel->id_perusahaan = $iup->id_perusahaan;
        
        $listRKT = CHtml::listData(
            Rkt::model()->findAll(
                array(
                    'condition' => 'id_perusahaan = ' . $iup->idPerusahaan->id_perusahaan,
                    'order' => 'tahun_mulai DESC'
                )
            ), 'tahun_mulai', 'tahun_mulai'
        );
        
        $periodeModel->rkt = current($listRKT);
        
        //debug($periodeModel);
        //die("test");        
        $this->render('index', array(
            'iup' => $iup,
            'idPerusahaan' => $id,
            'periodeModel' => $periodeModel,
        ));
        
    }
    
    public function actionPemanenan() {
        $this->layout = false;       
        $this->render('pemanenan', array());                
    }
    
    public function actionPemeliharaan() {
        $this->layout = false;       
        $this->render('pemeliharaan', array());        
            
    }
    
    public function actionPengadaanBibit() {
        $query = "
            SELECT
                master_jenis_produksi_lahan.jenis_produksi,
                master_jenis_tanaman.nama_tanaman,
                rkt_bibit.jumlah AS rencana,
                CONCAT(master_jenis_tanaman.nama_tanaman,' - ',rkt_bibit.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_bibit.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_bibit.tahun) as periode,
                realisasi_rkt_bibit.realisasi,
                realisasi_rkt_bibit.persentase
            FROM
                realisasi_rkt_bibit
                INNER JOIN rkt_bibit ON realisasi_rkt_bibit.id_rkt_bibit = rkt_bibit.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_bibit.id_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_jenis_tanaman ON rkt_bibit.id_jenis_tanaman = master_jenis_tanaman.id
                INNER JOIN master_bulan ON realisasi_rkt_bibit.id_bulan = master_bulan.id            
                INNER JOIN rkt ON rkt_bibit.id_rkt = rkt.id
            WHERE 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_bibit.tahun, master_bulan.id
        ";
        //die($query);
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('pengadaan-bibit', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }
    
    public function actionPenyiapanLahan() {
        $query = "
            SELECT
                master_blok.nama_blok,
                master_jenis_lahan.jenis_lahan,
                rkt_siap_lahan.jumlah AS rencana,
                CONCAT(master_blok.nama_blok,' - ', rkt_siap_lahan.jumlah) as blok_rencana,
                master_bulan.bulan,
                realisasi_rkt_siap_lahan.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_siap_lahan.tahun) as periode,
                realisasi_rkt_siap_lahan.realisasi,
                realisasi_rkt_siap_lahan.persentase
            FROM
                realisasi_rkt_siap_lahan
                INNER JOIN rkt_siap_lahan ON realisasi_rkt_siap_lahan.id_rkt_siap_lahan = rkt_siap_lahan.id
                INNER JOIN master_jenis_lahan ON rkt_siap_lahan.id_jenis_lahan = master_jenis_lahan.id
                INNER JOIN master_blok ON master_blok.id = rkt_siap_lahan.id_blok
                INNER JOIN rkt ON rkt_siap_lahan.id_rkt = rkt.id
                INNER JOIN master_bulan ON realisasi_rkt_siap_lahan.id_bulan = master_bulan.id
            WHERE 
                rkt_siap_lahan.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_siap_lahan.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('penyiapan-lahan', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }
    
    public function actionPenanaman() {
        $query = "
            SELECT
                master_jenis_produksi_lahan.jenis_produksi,
                master_jenis_lahan.jenis_lahan,
                master_jenis_tanaman.nama_tanaman,
                master_blok.nama_blok,
                rkt_tanam.jumlah AS rencana,
                CONCAT(master_jenis_tanaman.nama_tanaman,' - ', rkt_tanam.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_tanam.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_tanam.tahun) as periode,
                realisasi_rkt_tanam.realisasi,
                realisasi_rkt_tanam.persentase
            FROM
                realisasi_rkt_tanam
                INNER JOIN rkt_tanam ON realisasi_rkt_tanam.id_rkt_tanam = rkt_tanam.id
                INNER JOIN master_jenis_lahan ON rkt_tanam.id_jenis_lahan = master_jenis_lahan.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_tanam.id_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_jenis_tanaman ON rkt_tanam.id_jenis_tanaman = master_jenis_tanaman.id
                INNER JOIN master_blok ON master_blok.id = rkt_tanam.id_blok
                INNER JOIN master_bulan ON realisasi_rkt_tanam.id_bulan = master_bulan.id
                INNER JOIN rkt ON rkt_tanam.id_rkt = rkt.id            
            WHERE               
                rkt_tanam.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_tanam.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('penanaman', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }
    
    public function actionPenyulaman() {
        $query = "
            SELECT
                master_jenis_produksi_lahan.jenis_produksi,
                rkt_sulam.jumlah AS rencana,
                CONCAT(master_jenis_produksi_lahan.jenis_produksi,' - ',rkt_sulam.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_sulam.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_sulam.tahun) as periode,
                realisasi_rkt_sulam.realisasi,
                realisasi_rkt_sulam.persentase
            FROM
                realisasi_rkt_sulam
                INNER JOIN rkt_sulam ON realisasi_rkt_sulam.id_rkt_sulam = rkt_sulam.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_sulam.id_jenis_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN rkt ON rkt_sulam.id_rkt = rkt.id
                INNER JOIN master_bulan ON realisasi_rkt_sulam.id_bulan = master_bulan.id
            WHERE            
                rkt_sulam.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_sulam.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('penyulaman', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }
    

    public function actionPenjarangan() {
        $query = "
            SELECT
                master_jenis_produksi_lahan.jenis_produksi,
                rkt_jarang.jumlah AS rencana,
                CONCAT(master_jenis_produksi_lahan.jenis_produksi,' - ',rkt_jarang.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_jarang.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_jarang.tahun) as periode,
                realisasi_rkt_jarang.realisasi,
                realisasi_rkt_jarang.persentase
            FROM
                realisasi_rkt_jarang
                INNER JOIN rkt_jarang ON realisasi_rkt_jarang.id_rkt_jarang = rkt_jarang.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_jarang.id_jenis_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_bulan ON realisasi_rkt_jarang.id_bulan = master_bulan.id
                INNER JOIN rkt ON rkt_jarang.id_rkt = rkt.id
            WHERE            
                rkt_jarang.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_jarang.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('penjarangan', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }    

    public function actionPendangiran() {
        $query = "
            SELECT
                master_jenis_produksi_lahan.jenis_produksi,
                rkt_dangir.jumlah AS rencana,
                CONCAT(master_jenis_produksi_lahan.jenis_produksi,' - ',rkt_dangir.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_dangir.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_dangir.tahun) as periode,
                realisasi_rkt_dangir.realisasi,
                realisasi_rkt_dangir.persentase
            FROM
                realisasi_rkt_dangir
                INNER JOIN rkt_dangir ON realisasi_rkt_dangir.id_rkt_dangir = rkt_dangir.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_dangir.id_jenis_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_bulan ON realisasi_rkt_dangir.id_bulan = master_bulan.id
                INNER JOIN rkt ON rkt_dangir.id_rkt = rkt.id
            WHERE            
                rkt_dangir.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_dangir.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('pendangiran', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));        
    }    

    public function actionLuasPemanenan() {
        $query = "
            SELECT
                master_jenis_lahan.jenis_lahan,
                master_jenis_produksi_lahan.jenis_produksi,
                master_blok.nama_blok,
                master_jenis_tanaman.nama_tanaman,
                rkt_panen_areal.jumlah AS rencana,
                CONCAT(master_jenis_tanaman.nama_tanaman,' - ',rkt_panen_areal.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_panen_areal.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_panen_areal.tahun) as periode,
                realisasi_rkt_panen_areal.realisasi,
                realisasi_rkt_panen_areal.persentase
            FROM
                realisasi_rkt_panen_areal
                INNER JOIN rkt_panen_areal ON realisasi_rkt_panen_areal.id_rkt_panen_areal = rkt_panen_areal.id
                INNER JOIN master_jenis_lahan ON rkt_panen_areal.id_jenis_lahan = master_jenis_lahan.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_panen_areal.id_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_jenis_tanaman ON rkt_panen_areal.id_jenis_tanaman = master_jenis_tanaman.id
                INNER JOIN master_blok ON rkt_panen_areal.id_blok = master_blok.id
                INNER JOIN rkt ON rkt_panen_areal.id_rkt = rkt.id
                INNER JOIN master_bulan ON realisasi_rkt_panen_areal.id_bulan = master_bulan.id            
            WHERE            
                rkt_panen_areal.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_panen_areal.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('luas-pemanenan', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));            
        
    }    
    
    public function actionVolumeHasilTanaman() {
        $query = "
            SELECT
                master_jenis_lahan.jenis_lahan,
                master_jenis_produksi_lahan.jenis_produksi,
                master_blok.nama_blok,
                master_jenis_tanaman.nama_tanaman,
                rkt_panen_volume_tanaman.jumlah AS rencana,
                CONCAT(master_jenis_tanaman.nama_tanaman,' - ', rkt_panen_volume_tanaman.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_panen_volume_tanaman.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_panen_volume_tanaman.tahun) as periode,
                realisasi_rkt_panen_volume_tanaman.realisasi,
                realisasi_rkt_panen_volume_tanaman.persentase
            FROM
                realisasi_rkt_panen_volume_tanaman
                INNER JOIN rkt_panen_volume_tanaman ON realisasi_rkt_panen_volume_tanaman.id_rkt_panen_volume_tanaman = rkt_panen_volume_tanaman.id
                INNER JOIN master_jenis_lahan ON rkt_panen_volume_tanaman.id_jenis_lahan = master_jenis_lahan.id
                INNER JOIN master_jenis_produksi_lahan ON rkt_panen_volume_tanaman.id_produksi_lahan = master_jenis_produksi_lahan.id
                INNER JOIN master_jenis_tanaman ON rkt_panen_volume_tanaman.id_jenis_tanaman = master_jenis_tanaman.id
                INNER JOIN master_blok ON rkt_panen_volume_tanaman.id_blok = master_blok.id
                INNER JOIN rkt ON rkt_panen_volume_tanaman.id_rkt = rkt.id
                INNER JOIN master_bulan ON realisasi_rkt_panen_volume_tanaman.id_bulan = master_bulan.id
            WHERE            
                rkt_panen_volume_tanaman.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_panen_volume_tanaman.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('volume-hasil-tanam', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));                    
    }        
    
    public function actionVolumePenyiapanLahan() {
        $query = "
            SELECT
                master_jenis_kayu.nama_kayu,
                master_jenis_kelompok_kayu.nama_kelompok,
                rkt_panen_volume_siap_lahan.jumlah AS rencana,
                CONCAT(master_jenis_kelompok_kayu.nama_kelompok,' - ',rkt_panen_volume_siap_lahan.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_panen_volume_siap_lahan.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_panen_volume_siap_lahan.tahun) as periode,
                realisasi_rkt_panen_volume_siap_lahan.realisasi,
                realisasi_rkt_panen_volume_siap_lahan.persentase
            FROM
                realisasi_rkt_panen_volume_siap_lahan
                INNER JOIN rkt_panen_volume_siap_lahan ON realisasi_rkt_panen_volume_siap_lahan.id_rkt_panen_volume_siap_lahan = rkt_panen_volume_siap_lahan.id
                INNER JOIN master_jenis_kayu ON rkt_panen_volume_siap_lahan.id_jenis_kayu = master_jenis_kayu.id
                INNER JOIN master_jenis_kelompok_kayu ON rkt_panen_volume_siap_lahan.id_jenis_kelompok_kayu = master_jenis_kelompok_kayu.id
                INNER JOIN master_bulan ON realisasi_rkt_panen_volume_siap_lahan.id_bulan = master_bulan.id
                INNER JOIN rkt ON rkt_panen_volume_siap_lahan.id_rkt = rkt.id            
            WHERE            
                rkt_panen_volume_siap_lahan.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_panen_volume_siap_lahan.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('volume-penyiapan-lahan', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));             
    }            
    
    public function actionPemasaran() {
        $query = "
            SELECT
                master_jenis_pemasaran.nama_pemasaran,
                rkt_pasar.jumlah AS renncana,
                CONCAT(master_jenis_pemasaran.nama_pemasaran,' - ',rkt_pasar.jumlah) as jenis_rencana,
                master_bulan.bulan,
                realisasi_rkt_pasar.tahun,
                CONCAT(master_bulan.bulan,' ',realisasi_rkt_pasar.tahun) as periode,
                realisasi_rkt_pasar.realisasi,
                realisasi_rkt_pasar.persentase
            FROM
                realisasi_rkt_pasar
                INNER JOIN rkt_pasar ON realisasi_rkt_pasar.id_rkt_pasar = rkt_pasar.id
                INNER JOIN master_jenis_pemasaran ON rkt_pasar.id_pemasaran = master_jenis_pemasaran.id
                INNER JOIN rkt ON rkt_pasar.id_rkt = rkt.id
                INNER JOIN master_bulan ON realisasi_rkt_pasar.id_bulan = master_bulan.id
            WHERE            
                rkt_pasar.jumlah > 0 AND 
                rkt.id_perusahaan = '".$_POST['FormPeriodeRekapPrasyarat']['id_perusahaan']."' AND 
                rkt.tahun_mulai = '".$_POST['FormPeriodeRekapPrasyarat']['rkt']."'                
            ORDER BY realisasi_rkt_pasar.tahun, master_bulan.id
        ";        
        $model = Yii::app()->db->createCommand($query)->queryAll();
        //debug($model);
        //die( __FUNCTION__ );
        $this->layout = false;        
        $this->render('pemasaran', array(
            'model' => $this->setPivotData($model, ['realisasi', 'persentase']),
            'tahun' => $_POST['FormPeriodeRekapPrasyarat']['rkt']
        ));             
    }
    
    function setPivotData($rows, $keydata)
    {
        $data = "[";
        foreach($rows as $idx => $val)
        {
           $data .= "{";
           $y=0;
           foreach($val as $keyfield => $valfield)
           {
               if(in_array($keyfield, $keydata)){
                   $data .= '"'.$keyfield.'":'.$valfield;
               } else {
                   $data .= '"'.$keyfield.'":"'.$valfield.'"';
               }
               //if($valfield != end($val)) $data .= ',';
               if($y < count($val)-1) $data .= ',';
               $y++;
           }           
           $data .= "}";
           if($val != end($rows)) $data .= ",";
        }

        $data .= "]";

        return $data;
    }
    
    
}